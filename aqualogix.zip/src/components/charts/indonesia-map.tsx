"use client";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

// Simplified representative positions (not true geographic projection / GeoJSON boundaries).
// Good enough for an at-a-glance ops view; swap for a real GeoJSON + d3-geo projection
// in a later iteration if pixel-accurate province shapes are required.
const PROVINCE_POINTS = [
  { name: "Sulawesi Selatan", x: 480, y: 230, shipments: 320, risk: "low" as const },
  { name: "Jawa Timur", x: 340, y: 280, shipments: 410, risk: "low" as const },
  { name: "Maluku", x: 620, y: 250, shipments: 95, risk: "high" as const },
  { name: "Sulawesi Utara", x: 500, y: 140, shipments: 140, risk: "medium" as const },
  { name: "DKI Jakarta", x: 290, y: 260, shipments: 260, risk: "low" as const },
  { name: "Kalimantan Timur", x: 420, y: 170, shipments: 178, risk: "medium" as const },
];

const RISK_COLOR = { low: "#10B981", medium: "#F59E0B", high: "#EF4444" };

export function IndonesiaMap() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-foreground text-sm font-medium">
          Sebaran Pengiriman per Provinsi (Indonesia)
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Representasi posisi disederhanakan — bukan batas wilayah GeoJSON presisi.
        </p>
      </CardHeader>
      <CardContent>
        <svg viewBox="0 0 700 340" className="w-full h-auto" role="img" aria-label="Peta sebaran pengiriman per provinsi">
          <rect x={0} y={0} width={700} height={340} rx={16} fill="hsl(var(--muted) / 0.25)" />
          {/* Faint archipelago guideline */}
          <path
            d="M 60 260 Q 200 220 340 260 T 640 220"
            stroke="hsl(var(--border))"
            strokeWidth={2}
            fill="none"
            strokeDasharray="4 6"
          />
          {PROVINCE_POINTS.map((p) => (
            <g key={p.name} transform={`translate(${p.x}, ${p.y})`}>
              <circle r={Math.max(8, p.shipments / 25)} fill={RISK_COLOR[p.risk]} fillOpacity={0.75}>
                <title>{`${p.name}: ${p.shipments} pengiriman aktif`}</title>
              </circle>
              <text y={-Math.max(8, p.shipments / 25) - 6} fontSize="11" textAnchor="middle" fill="hsl(var(--foreground))">
                {p.name}
              </text>
            </g>
          ))}
        </svg>
        <div className="mt-2 flex gap-4 text-xs text-muted-foreground">
          {(["low", "medium", "high"] as const).map((r) => (
            <span key={r} className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full" style={{ background: RISK_COLOR[r] }} />
              Risiko {r === "low" ? "rendah" : r === "medium" ? "sedang" : "tinggi"}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
