"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bell, Search, Moon, Sun, LogOut } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export function Header() {
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const [notifOpen, setNotifOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  async function handleLogout() {
    await fetch("/api/auth/logout", {
      method: "POST",
      headers: { "X-Requested-With": "AquaLogix" },
    });
    toast.success("Berhasil keluar.");
    router.push("/login");
  }

  return (
    <header className="sticky top-0 z-30 mx-3 mt-3 flex items-center justify-between rounded-lg border border-white/10 bg-card/70 px-3 py-2 backdrop-blur-xl shadow-card">
      <button
        onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }))}
        className="flex w-72 items-center gap-2 rounded-sm border border-border bg-muted/40 px-3 py-1.5 text-sm text-muted-foreground transition hover:bg-muted/60"
        aria-label="Buka command palette (Cmd+K)"
      >
        <Search className="h-4 w-4" aria-hidden="true" />
        <span>Cari pengiriman, vendor...</span>
        <kbd className="ml-auto rounded border border-border px-1.5 py-0.5 text-[10px]">⌘K</kbd>
      </button>

      <div className="flex items-center gap-1.5">
        <Button
          variant="ghost"
          size="icon"
          aria-label="Ubah tema"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          <Sun className="h-4 w-4 hidden dark:block" aria-hidden="true" />
          <Moon className="h-4 w-4 block dark:hidden" aria-hidden="true" />
        </Button>
        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Notifikasi"
            aria-expanded={notifOpen}
            onClick={() => setNotifOpen((v) => !v)}
          >
            <Bell className="h-4 w-4" aria-hidden="true" />
            <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-danger" />
          </Button>
          {notifOpen && (
            <div
              role="menu"
              className="absolute right-0 mt-2 w-72 rounded-sm border border-border bg-popover p-2 text-sm shadow-card animate-fade-up"
            >
              <p className="px-2 py-1.5 font-medium">Notifikasi</p>
              <div className="px-2 py-1.5 text-muted-foreground">
                3 pengiriman berisiko terlambat di rute Makassar–Surabaya.
              </div>
            </div>
          )}
        </div>
        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="h-8 w-8 rounded-full bg-gradient-to-br from-accent to-accent-dark"
            aria-label="Menu akun"
            aria-expanded={menuOpen}
          />
          {menuOpen && (
            <div
              role="menu"
              className="absolute right-0 mt-2 w-44 rounded-sm border border-border bg-popover p-1 text-sm shadow-card animate-fade-up"
            >
              <button
                onClick={handleLogout}
                className="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left hover:bg-muted/50"
              >
                <LogOut className="h-4 w-4" aria-hidden="true" />
                Keluar
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
